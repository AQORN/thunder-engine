name "fail2"
description "Default run_list for testing"
run_list(
  "recipe[XXX]"
  )
