name "development"
description "Nova development environment"
