name "qa"
description "Nova qa environment"
